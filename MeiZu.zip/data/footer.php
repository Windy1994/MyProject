<?php
	header("Content-Type:text/html;charset=utf-8");
	$html='
	     <div class="m_footer">
                        <div class="footer_header">
                            <ul>
                                <li>
                                    <i></i>
                                    <p>7天无理由退货</p>
                                </li>
                                <li>
                                    <i></i>
                                    <p>15天换货保障</p>
                                </li>
                                <li>
                                    <i></i>
                                    <p>1年免费保修</p>
                                </li>
                                <li>
                                    <i></i>
                                    <p>百城速达</p>
                                </li>
                                <li>
                                    <i></i>
                                    <p>全场免费包邮</p>
                                </li>
                                <li>
                                    <i></i>
                                    <p>2000多家专卖店</p>
                                </li>
                            </ul>
                        </div>
                        <div class="footer_body">
                            <ul>
                                <li>帮助说明</li>
                                <li><a href="">支付方式</a></li>
                                <li><a href="">配送说明</a></li>
                                <li><a href="">售后服务</a></li>
                                <li><a href="">付款帮助</a></li>
                            </ul>
                            <ul>
                                <li>Flyme</li>
                                <li><a href="">开放平台</a></li>
                                <li><a href="">固件下载</a></li>
                                <li><a href="">软件商店</a></li>
                                <li><a href="">查找手机</a></li>
                            </ul>
                            <ul>
                                <li>关于我们</li>
                                <li><a href="">关于魅族</a></li>
                                <li><a href="">加入我们</a></li>
                                <li><a href="">联系我们</a></li>
                                <li><a href="">法律声明</a></li>
                            </ul>
                            <ul>
                                <li>关注我们</li>
                                <li><a href="">新浪微博</a></li>
                                <li><a href="">腾讯微博</a></li>
                                <li><a href="">QQ空间</a></li>
                                <li><a href="">官方微信</a></li>
                            </ul>
                        </div>
                        <div class="footer_bottom">
                            ©2016 Meizu Telecom Equipment Co., Ltd. All rights reserved. 备案号：粤ICP备13003602号-2 经营许可证编号：粤B2-20130198
                        </div>
                    </div>
	';
	echo $html;